import cv2
import mediapipe as mp
import serial
import time

# ==============================
# Initialize MediaPipe Hand Detector
# ==============================
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7
)
mp_drawing = mp.solutions.drawing_utils

# ==============================
# Initialize Serial Communication with Arduino
# ==============================
try:
    arduino = serial.Serial('COM3', 9600, timeout=1)
    time.sleep(2)  # Wait for Arduino to initialize
    print("✅ Arduino connected successfully")
except Exception as e:
    print(f"❌ Error connecting to Arduino: {e}")
    arduino = None

# ==============================
# Open Webcam
# ==============================
cap = cv2.VideoCapture(0)

# ==============================
# Helper Functions
# ==============================
def get_finger_status(hand_landmarks):
    """
    Improved detection:
    - Thumb handled separately (based on x-axis)
    - Other fingers use y-axis comparison
    """
    # Thumb detection (for right hand — selfie view)
    thumb_tip = hand_landmarks[4]
    thumb_ip = hand_landmarks[3]  # FIXED: Added missing index
    thumb_open = 1 if thumb_tip.x < thumb_ip.x else 0  # flip for left hand if needed

    # Other fingers: index, middle, ring, little
    fingers = [
        {'tip': 8, 'mcp': 5},   # index
        {'tip': 12, 'mcp': 9},  # middle
        {'tip': 16, 'mcp': 13}, # ring
        {'tip': 20, 'mcp': 17}  # little
    ]

    finger_status = [thumb_open]

    for finger in fingers:
        tip_y = hand_landmarks[finger['tip']].y
        mcp_y = hand_landmarks[finger['mcp']].y

        if mcp_y - tip_y > 0.05:  # tip is above mcp → open
            finger_status.append(1)
        else:
            finger_status.append(0)

    return finger_status  # [thumb, index, middle, ring, little]


def get_gesture_and_angles(finger_status):
    """
    Map finger combinations to gesture number and servo angles
    Returns: (gesture_number, [servo1, servo2, servo3, servo4, servo5])
    """
    thumb, index, middle, ring, little = finger_status

    # Gesture 1: Only index open
    if thumb == 0 and index == 1 and middle == 0 and ring == 0 and little == 0:
        return 1, [135, 0, 135, 135, 0]

    # Gesture 2: Index and Middle open
    elif thumb == 0 and index == 1 and middle == 1 and ring == 0 and little == 0:
        return 2, [135, 0, 0, 135, 0]

    # Gesture 3: Index, Middle, Ring open
    elif thumb == 0 and index == 1 and middle == 1 and ring == 1 and little == 0:
        return 3, [135, 0, 0, 0, 0]

    # Gesture 4: All fingers open except thumb
    elif thumb == 0 and index == 1 and middle == 1 and ring == 1 and little == 1:
        return 4, [135, 0, 0, 0, 135]

    # Gesture 5: All open
    elif thumb == 1 and index == 1 and middle == 1 and ring == 1 and little == 1:
        return 5, [0, 0, 0, 0, 135]

    # Gesture 6: Thumb and Index open only ("L" gesture)
    elif thumb == 1 and index == 1 and middle == 0 and ring == 0 and little == 0:
        return 6, [0, 0, 135, 135, 0]

    # Gesture 7: Middle, Ring, Little open (Index closed)
    elif thumb == 0 and index == 0 and middle == 1 and ring == 1 and little == 1:
        return 7, [135, 135, 0, 0, 135]

    # Gesture 8: Index and Ring open
    elif thumb == 0 and index == 1 and middle == 0 and ring == 1 and little == 1:
        return 8, [135, 0, 135, 0, 135]

    # Gesture 9: Only thumb open
    elif thumb == 0 and index == 1 and middle == 1 and ring == 0 and little == 1:
        return 9, [135, 0, 0, 135, 135]

    # Gesture 10: All closed (fist)
    elif thumb == 0 and index == 0 and middle == 0 and ring == 0 and little == 0:
        return 10, [135, 135, 135, 135, 0]

    # Default: Unrecognized gesture = 0
    else:
        return 0, [0,0,0,0,0]


def send_to_arduino(angles):
    """Send servo angles to Arduino via serial for PCA9685"""
    if arduino and arduino.is_open:
        # Format: CH0:angle,CH1:angle,CH2:angle,CH3:angle,CH4:angle
        command = f"CH8:{angles[0]},CH15:{angles[1]},CH5:{angles[2]},CH3:{angles[3]},CH12:{angles[4]}\n"
        try:
            arduino.write(command.encode())
        except Exception as e:
            print(f" Error sending to Arduino: {e}")

# ==============================
# Main Loop
# ==============================
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)  # selfie view
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(rgb_frame)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            # Draw hand landmarks
            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

            # Get finger states
            finger_status = get_finger_status(hand_landmarks.landmark)

            # Get gesture + servo angles
            gesture, angles = get_gesture_and_angles(finger_status)

            # Send to Arduino
            send_to_arduino(angles)

            # Display info
            gesture_text = f"Gesture: {gesture}" if gesture != 0 else "Gesture: Unknown"
            cv2.putText(frame, gesture_text, (10, 80),
                        cv2.FONT_HERSHEY_SIMPLEX, 2.0, (0, 0, 0) if gesture != 0 else (0, 0, 255), 5)
            #cv2.putText(frame, f"Fingers: T:{finger_status[0]} I:{finger_status[1]} M:{finger_status[2]} R:{finger_status[3]} L:{finger_status[4]}", 
                        #(10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
            #cv2.putText(frame, f"Angles: {angles}", (10, 110),
                        #cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
            
            # Read Arduino feedback
            if arduino and arduino.in_waiting:
                line = arduino.readline().decode().strip()
                print(f"[Arduino]: {line}")

    cv2.imshow("🤖 Hand Gesture Recognition (PCA9685)", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


# ==============================
# Clean 
# ==============================
cap.release()
cv2.destroyAllWindows()
if arduino and arduino.is_open:
    arduino.close()
    print("🔌 Arduino connection closed")