Install media pipe library and OpenCV libraries 

be ready with your laptop camera 

place your hand and do the actions you want the robotic arm to immitate